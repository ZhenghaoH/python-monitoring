# python-monitoring
使用Python监控计算机信息，生成txt文件并进行收发
