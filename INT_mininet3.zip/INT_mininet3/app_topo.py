from topomaker import *
class Switch:
    def __init__(self, name, thriftPort, portSum):
        self.name = name
        self.thriftPort = thriftPort
        self.portSum = portSum
        self.ports = []  # This should be a list of port objects


class Port:
    def __init__(self, deviceName):
        self.deviceName = deviceName


class Host:
    def __init__(self, name, ipAddress, macAddress, ovsIpAddress=None):
        self.name = name
        self.ipAddress = ipAddress
        self.macAddress = macAddress
        self.ovsIpAddress = ovsIpAddress


class AppTopo:
    def __init__(self):
        self.switches = []
        self.hosts = []

    def addSwitch(self, switch):
        self.switches.append(switch)

    def addHost(self, host):
        self.hosts.append(host)


def create_app_topo():
    app_topo = AppTopo()

    # Example of creating switches
    switch1 = Switch(name='s1', thriftPort=9091, portSum=2)
    # switch2 = Switch(name='s2', thriftPort=9092, portSum=2)

    # Adding ports to switches
    switch1.ports.append(Port(deviceName='h1'))
    switch1.ports.append(Port(deviceName='h2'))
    switch1.ports.append(Port(deviceName='h3'))
    # switch2.ports.append(Port(deviceName='h2'))
    # switch2.ports.append(Port(deviceName='s1'))

    app_topo.addSwitch(switch1)
    # app_topo.addSwitch(switch2)

    # Example of creating hosts
    host1 = Host(name='h1', ipAddress='172.18.0.152', macAddress='00:00:00:00:01:01')
    host2 = Host(name='h2', ipAddress='172.18.0.251', macAddress='00:00:00:00:02:02')
    host3 = Host(name='h3', ipAddress='172.18.0.250', macAddress='00:00:00:00:03:03')

    app_topo.addHost(host1)
    app_topo.addHost(host2)
    app_topo.addHost(host3)

    return app_topo


if __name__ == '__main__':
    # Create the app_topo
    app_topo = create_app_topo()
    # Example paths
    switchPath = 'simple_switch'
    jsonPath = 'INT.json'

    # Instantiate the TopoMaker and generate Mininet topology
    topo_maker = TopoMaker(switchPath, jsonPath, app_topo)
    topo_maker.genMnTopo()
    topo_maker.getCLI()
    # topo_maker.stopMnTopo()
    # topo_maker.cleanMn()
